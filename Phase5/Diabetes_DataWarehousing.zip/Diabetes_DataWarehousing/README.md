## Diabetes datawarehousing with ETL process using python pandas

### Overview

This project is aimed at creating a data warehouse for diabetes-related data by employing an ETL (Extract, Transform, Load) process. The primary goal is to provide a structured, easily accessible repository for diabetes data that can be used for analysis and reporting. Python, specifically the pandas library, is used for data processing, and a MySQL database is utilized for storage.

 ### Technical Aspect
 
 This Project is mainly divided into two parts:
 
 1. Extract and preprocess the dataset.
 2. Transform and load the data into MySQL.

**About the repository Structure :**

- Project consist of `ETL_transform.ipynb` which is used to clean, transform and explore the dataset.
- `ETL_Python.py` script is used to connect with SQL database.
- `SQL_query.sql` is used to load the dataset into MySQL.

### Run 

- To display the dataset : SQL_query.sql

### Software used 

- Jupyter Notebook: This is used to perform extract and transform step in ETL process.
- Visual Studio Code: This is used to make connection with the database.
- MySQL Workbench 8.0 CE: This serves as a destination of the dataset.

### Future work 

- use IBM db2 warehouse with different types of data sources.
- perform advanced data transformation steps.
- train this data with advanced machine learning model and deploy with better user interface.








  
  
  


